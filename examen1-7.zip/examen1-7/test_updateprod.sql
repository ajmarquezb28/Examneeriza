-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-04-2021 a las 01:55:34
-- Versión del servidor: 10.4.18-MariaDB
-- Versión de PHP: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `test_updateprod`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `distrito` varchar(300) NOT NULL,
  `direccion` varchar(300) NOT NULL,
  `fecha` varchar(300) NOT NULL,
  `telefono` varchar(300) NOT NULL,
  `Id` int(11) NOT NULL,
  `tipo_pago` varchar(300) NOT NULL,
  `referencia` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`distrito`, `direccion`, `fecha`, `telefono`, `Id`, `tipo_pago`, `referencia`) VALUES
('surco', 'surco', '2021-01-01', '987874848', 1, 'paypal', 'paypal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tblprod`
--

CREATE TABLE `tblprod` (
  `id` int(10) UNSIGNED NOT NULL,
  `prod_code` varchar(20) NOT NULL,
  `prod_name` varchar(50) NOT NULL,
  `prod_ctry` varchar(50) NOT NULL,
  `prod_qty` int(20) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tblprod`
--

INSERT INTO `tblprod` (`id`, `prod_code`, `prod_name`, `prod_ctry`, `prod_qty`, `price`, `image`) VALUES
(8, '002', 'Gardenia', 'PanaderÃ­a', 25, '2.50', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(9, '003', 'Coco Crunch', 'Cereales', 15, '5.25', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(10, '0001', 'Red Bull', 'Bebidas', 50, '1.25', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(11, '004', 'Queso Eden', 'LÃ¡cteos', 30, '3.25', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(12, '005', 'Kiwi', 'Frutas', 20, '2.00', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(13, '006', 'Porkchop', 'Carnes', 60, '4.25', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(14, '007', 'Pimienta negra', 'Especies', 5, '1.25', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(15, '008', 'Miel de aveja', 'Edulcorantes', 41, '3.00', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(16, '009', 'Coliflor', 'Vegetales', 15, '1.50', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(18, '0011', 'Uva  ', 'Bebidas', 22, '0.50', 'https://th.bing.com/th/id/R21b4fef18b096a813c6075682b07e862?rik=EHSCbUvUHniZng&riu=http%3a%2f%2fwww.food-project.it%2fwp-content%2fuploads%2f2018%2f03%2fFP-Sviluppo_nuovi_prodotti_alimentari-2018-835x835.png&ehk=wXNsuMOC%2bdb6BhASWwtfZYxem7PDdTRA63a6c7Ekt3w%3d&risl=&pid=ImgRaw'),
(19, '001', 'Quaker Oats', 'Cereales', 98, '3.25', 'https://i.pinimg.com/originals/fc/a9/6a/fca96abb56863d3709abc2ea6cfe9608.jpg'),
(21, '0015', 'Avena quaker', 'Cereales', 49, '4.25', 'https://i.pinimg.com/originals/fc/a9/6a/fca96abb56863d3709abc2ea6cfe9608.jpg'),
(22, '32', '23', '2323', 23, '544.00', 'https://i.pinimg.com/originals/fc/a9/6a/fca96abb56863d3709abc2ea6cfe9608.jpg'),
(23, '232', 'prueba2', 'artefactos', 4, '500.00', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`Id`);

--
-- Indices de la tabla `tblprod`
--
ALTER TABLE `tblprod`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `book_id` (`prod_code`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `tblprod`
--
ALTER TABLE `tblprod`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
